"""A python ascii-text-art, pokemon-style game in the terminal using ANSI escape sequences."""
