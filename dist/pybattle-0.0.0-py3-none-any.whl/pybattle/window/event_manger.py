from queue import Queue
from time import sleep

from pybattle.ansi.cursor import Cursor
from pybattle.window.grid.coord import Coord
from pybattle.window.screen.scene import Scene as S


class Scene:
    scenes = set()

    def __init__(self, scene: str, pos: Coord = ...):
        self.scene = scene
        self.pos = pos

        type(self).scenes.add(self)

    def remove(self):
        type(self).scenes.remove(self)

    @classmethod
    def draw(cls):
        for scene in cls.scenes:
            for line in scene.scene.splitlines():
                if scene.pos is ...:
                    scene.pos = Cursor.pos

                Cursor.move(scene.pos)
                scene.pos.y += 1
                
                print(line, end="")

        # Cursor.move(Coord(0, 0))


S.clear()
Cursor.move(Coord(0, 0))
Scene("x", Coord(0, 0))
Scene("y", Coord(2, 2))

Scene.draw()


class Event:
    fps = 30
    events = []

    def __init__(self, func, sleep):
        self.every_frames = type(self).fps * sleep
        self.func = func

        type(self).events.append(self)

    @classmethod
    def play(cls):
        frame_count = 0
        while True:
            sleep(1 / cls.fps)
            frame_count += 1

            for event in cls.events:
                if frame_count % event.every_frames == 0:
                    event.func()

            Scene.draw()


# def x():
#     Scene("x", Coord(0, 0))


# def y():
#     Scene("y", Coord(0, 0))


# Event(x, 1)
# Event(y, 5)
# Event.play()

# class EventManager:
#     events = []
