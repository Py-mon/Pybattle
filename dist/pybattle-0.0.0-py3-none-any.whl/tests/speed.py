import pybattle.log.speed
