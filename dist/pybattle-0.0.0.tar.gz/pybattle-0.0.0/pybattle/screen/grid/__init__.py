"""The layout of the text and the fundamentals."""
