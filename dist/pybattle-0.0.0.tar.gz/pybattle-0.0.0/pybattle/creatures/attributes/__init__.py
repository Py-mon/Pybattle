"""All the pymon and creatures special attributes that add unique things to them"""
