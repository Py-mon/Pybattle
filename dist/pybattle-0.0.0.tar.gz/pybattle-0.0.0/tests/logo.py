from rich import print


print(r'''[on grey7]
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                        [bold deep_sky_blue4]__________[spring_green1]       [dark_red]__________                                                             
                        [bold deep_sky_blue4]\______   \\[spring_green1]___ __[dark_red]\______   \                                                           
                        [bold deep_sky_blue4] |     ___/[spring_green1]   |  |[dark_red]|    |  _/                                                            
                        [bold deep_sky_blue4] |    |   [spring_green1] \___  |[dark_red]|    |   \                                                            
                        [bold deep_sky_blue4] |____|   [spring_green1] / ____|[dark_red]|______  /                                                            
                        [bold deep_sky_blue4]          [spring_green1] \/     [dark_red]       \/                                                     
                                                                                                 
                                                                                                                                                     
                                                                                                                                                     
                                                                                                                                                     
                                                                                                                                                     
                                                                                                                                                     
                                                                                                                                                     
                                                                                                                                                     
                                                                                                                                                     
                                                                                                                                                     
                                                                                                                                                     
                                                                                                                                                     
                                                                                                                                                     
                        [bold deep_sky_blue4]__________ [red]__________                                                                                 
                        [bold deep_sky_blue4]\______   \\[red]\______   \                                                                                
                        [bold deep_sky_blue4] |     ___/ [red]|    |  _/                                                                                
                        [bold deep_sky_blue4] |    |     [red]|    |   \                                                                                
                        [bold deep_sky_blue4] |____|     [red]|______  /                                                                                
                        [bold deep_sky_blue4]                   [red]\/                                                                                 
                                                                                                                                                             
                                                                                                                                                                                                                                                                                                                                                                                                            
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                       [bold deep_sky_blue4]__________[spring_green1]                                                                                        
                       [bold deep_sky_blue4]\______   \\[spring_green1]___ ___                                                                              
                       [bold deep_sky_blue4] |     ___/[spring_green1]   |   |                                                                               
                       [bold deep_sky_blue4] |    |   [spring_green1] \___   |                                                                               
                       [bold deep_sky_blue4] |____|    [spring_green1]/ _____|                                                                             
                       [bold deep_sky_blue4]    [red]Battle [spring_green1]\/                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                                                                                                                                                          
                        [bold deep_sky_blue4]__________[spring_green1]        [dark_red]                                                            
                        [bold deep_sky_blue4]\______   \\[spring_green1]___ ___ [dark_red]                                                           
                        [bold deep_sky_blue4] |     ___/[spring_green1]   |   |[dark_red]                                                            
                        [bold deep_sky_blue4] |    |   [spring_green1] \___   |[dark_red]                                                            
                        [bold deep_sky_blue4] |____|    [spring_green1]/ _____|[dark_red]                                                            
                        [bold deep_sky_blue4]           [spring_green1]\/     [dark_red]                                                            
                 ___            __    __   __                                                                                                       
                 \_ |__ _____ _/  |__/  |_|  |   ____                                                                                                       
                  | __ \\__  \\   __\   __|  | _/ __ \                                                                                                      
                  | \_\ \/ __ \|  |  |  | |  |_\  ___/                                                                                                      
                  |___  /\___  |__|  |__| |____/\___ \                                                                                                      
                      \/     \/                     \/                                                                                                      
                                                                                                                                                           
                                                                                                                                                       
                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    
                                                                                                                                                    
                        [bold deep_sky_blue4]__________[spring_green1]         [dark_red]___            __    __   __                                
                        [bold deep_sky_blue4]\______   \\[spring_green1]___ ___ [dark_red]\_ |__ _____ _/  |__/  |_|  |   ____                                
                        [bold deep_sky_blue4] |     ___/[spring_green1]   |   |[dark_red] | __ \\__  \\   __\   __|  | _/ __ \                                 
                        [bold deep_sky_blue4] |    |   [spring_green1] \___   |[dark_red] | \_\ \/ __ \|  |  |  | |  |_\  ___/                                 
                        [bold deep_sky_blue4] |____|    [spring_green1]/ _____|[dark_red] |___  /\___  |__|  |__| |____/\___ \                                
                        [bold deep_sky_blue4]           [spring_green1]\/      [dark_red]     \/     \/                     \/                                 
                                                                                                           
                                                                                                                                                     
                                                                                                                                                     
                                                                                                                                                     
                                                                                                                                                     
                                                                                                                                                     
                                                                                                                                                     
                                                                                                                                                     
                                                                                                                                                     
                                                                                                                                                     
''')
